function setup() {
	createCanvas(windowWidth,windowHeight);
	background('white');
}

function draw() {
	noStroke();
  	fill(random(0,255), random(0,255), random(0,255));
	ellipse(random(0, windowWidth), random(0,windowHeight), 50, 50);
}