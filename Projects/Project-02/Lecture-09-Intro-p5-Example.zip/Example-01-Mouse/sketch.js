function setup() {
	createCanvas(640,480);
	background(0,0,255);
}

function draw() {
  /* 
  try uncommenting the background function in the draw()
  and see how your sketch changes 
  */

  //background(0,0,255);
  
  if(mouseIsPressed){
  	fill(0);
  }else{
  	fill(255);
  }
  
  ellipse(mouseX, mouseY, 80, 80);
  print(mouseX);
}