var canvas01;

function setup() {

	canvas01 = createCanvas(windowWidth/2 - 20,500); //subtract 20 to make it all fit horizontally
	canvas01.class('pink-squares');
	canvas01.id('lemons');
	canvas01.parent('sketch-container');
	/*
	position function assigns absolute positioning to your canvas
	*/
	//canvas01.position(100,100);
	background('white');

}

function draw() {	
 	fill('pink');
	rect(random(0,1000), random(0,1000), 50, 50);
}

/*
this makes your sketch responsive to your browser
great for viewing your sketch on mobile
*/
function windowResized(){
	resizeCanvas(windowWidth, windowHeight);
}
