function setup() {
	createCanvas(windowWidth,windowHeight);
	background(0,0,255);
}

function draw() {
	noLoop();
	background(0,0,255);
	var names=["Grace", "Kermen", "Richa", "Zoey", "Gabby", "Monique", "Megan", "Angelo", "Jacqueline", "Alex", "Shruti", "Rebecca", "Jay", "Logan" ];
	var name = random(names);
	textAlign(CENTER);
	textSize(100);
	fill(255,255,255);
	text(name, width/2, height/2);

}
function windowResized(){
	resizeCanvas(windowWidth, windowHeight);
}
