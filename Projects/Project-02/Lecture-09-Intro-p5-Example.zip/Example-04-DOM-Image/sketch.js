var img;

function setup() {
	/*
	try moving the createImg function before createCanvas and check what happens in your browser
	*/
	//img = createImg('cute-animal.jpg');
	createCanvas(windowWidth,300);
	background('white');
	img = createImg('cute-animal.jpg'); //<--This is a function specific to p5 DOM library
}

function draw() {
	image(img, 100, 200, 100, 70);
	
	noStroke();
  	fill(random(0,255), random(0,255), random(0,255));
	ellipse(random(0, windowWidth), random(0,windowHeight), 50, 50);
}