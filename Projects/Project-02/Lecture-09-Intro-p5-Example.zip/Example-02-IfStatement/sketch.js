//Declare your variables

var x = 0;
var y = 0;

function setup() {
  //Full width Canvas
	createCanvas(windowWidth, windowHeight);
	background(0,0,255);
}

function draw() {
  ellipse(x, y, 50, 50);
 
  x = x+10;
  if(x > width){

    x = 0;
    y = y+50;

  }
//Use the following code for change the y direction
/*
  y= y+10;
  if(y > height){
    y =0;
    x = x+50;
  }
*/

//Check your x & y values with the inspect tool on Chrome browser
  console.log(x);
  console.log(y);
}